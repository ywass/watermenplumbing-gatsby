import React from 'react'
import Layout from '../../../../../components/layout'
import Nov20FirstBlog from '../../../../../components/BlogPages/2020Pages/November2020Pages/Nov20FirstBlog/Nov20FirstBlog'
function index() {
  return (
    <Layout>
        <Nov20FirstBlog/>
    </Layout>
  )
}

export default index