import React from 'react'
import Layout from '../../../../../components/layout'
import Aug20FirstBlog from '../../../../../components/BlogPages/2020Pages/August2020Pages/Aug20FirstBlog/Aug20FirstBlog'
function index() {
  return (
    <Layout>
        <Aug20FirstBlog/>
    </Layout>
  )
}

export default index