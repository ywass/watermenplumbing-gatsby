import React from 'react'
import Layout from '../../../../../components/layout'
import Apr20FirstBlog from '../../../../../components/BlogPages/2020Pages/April2020Pages/Apr20FirstBlog/Apr20FirstBlog'
function index() {
  return (
    <Layout>
        <Apr20FirstBlog/>
    </Layout>
  )
}

export default index