import React from 'react'
import Layout from '../../../../components/layout'
import October2020Pages from '../../../../components/BlogPages/2020Pages/October2020Pages/October2020Pages'
function index() {
  return (
    <Layout>
        <October2020Pages/>
    </Layout>
  )
}

export default index