import React from 'react'
import Layout from '../../../../../components/layout'
import Oct20FirstBlog from '../../../../../components/BlogPages/2020Pages/October2020Pages/Oct20FirstBlog.js/Oct20FirstBlog'
function index() {
  return (
    <Layout>
        <Oct20FirstBlog/>
    </Layout>
  )
}

export default index