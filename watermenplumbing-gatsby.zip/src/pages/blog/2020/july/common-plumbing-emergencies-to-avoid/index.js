import React from 'react'
import Layout from '../../../../../components/layout'
import Jul20FirstBlog from '../../../../../components/BlogPages/2020Pages/July2020Pages/Jul20FirstBlog/Jul20FirstBlog'
function index() {
  return (
    <Layout>
        <Jul20FirstBlog/>
    </Layout>
  )
}

export default index