import React from 'react'
import Layout from '../../../../components/layout'
import July2020FirstBlog from '../../../../components/BlogPages/2020Pages/July2020Pages/July2020Pages'
function index() {
  return (
    <Layout>
        <July2020FirstBlog/>
    </Layout>
  )
}

export default index