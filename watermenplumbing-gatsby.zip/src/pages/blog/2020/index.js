import React from 'react'
import Layout from '../../../components/layout'
import TwentyTwentyPages from '../../../components/BlogPages/2020Pages/2020Pages'
function index() {
  return (
    <Layout>
        <TwentyTwentyPages/>
    </Layout>
  )
}

export default index