import React from 'react'
import Layout from '../../../../../components/layout'
import Mar20FirstBlog from '../../../../../components/BlogPages/2020Pages/March2020Pages/Mar20FirstBlog/Mar20FirstBlog'
function index() {
  return (
    <Layout>
        <Mar20FirstBlog/>
    </Layout>
  )
}

export default index