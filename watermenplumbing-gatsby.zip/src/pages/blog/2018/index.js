import React from 'react'
import Layout from '../../../components/layout'
import TwentyEighteenPages from '../../../components/BlogPages/2018Pages/2018Pages'
function index() {
  return (
    <Layout>
        <TwentyEighteenPages/>
    </Layout>
  )
}

export default index