import React from 'react'
import Layout from '../../../../../components/layout'
import Nov18FirstBlog from '../../../../../components/BlogPages/2018Pages/November2018Pages/Nov18FirstBlog/Nov18FirstBlog'
function index() {
  return (
    <Layout>
        <Nov18FirstBlog/>
    </Layout>
  )
}

export default index