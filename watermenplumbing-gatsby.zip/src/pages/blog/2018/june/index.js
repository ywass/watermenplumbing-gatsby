import React from 'react'
import Layout from '../../../../components/layout'
import June2018Pages from '../../../../components/BlogPages/2018Pages/June2018Pages/June2018Pages'
function index() {
  return (
    <Layout>
        <June2018Pages/>
    </Layout>
  )
}

export default index