import React from 'react'
import Layout from '../../../../../components/layout'
import Jun18FirstBlog from '../../../../../components/BlogPages/2018Pages/June2018Pages/Jun18FirstBlog/Jun18FirstBlog'
function index() {
  return (
    <Layout>
        <Jun18FirstBlog/>
    </Layout>
  )
}

export default index