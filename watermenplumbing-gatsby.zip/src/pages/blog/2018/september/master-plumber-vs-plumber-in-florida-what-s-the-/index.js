import React from 'react'
import Layout from '../../../../../components/layout'
import Sep18FirstBlog from '../../../../../components/BlogPages/2018Pages/September2018Pages/Sep18FirstBlog/Sep18FirstBlog'
function index() {
  return (
    <Layout>
        <Sep18FirstBlog/>
    </Layout>
  )
}

export default index