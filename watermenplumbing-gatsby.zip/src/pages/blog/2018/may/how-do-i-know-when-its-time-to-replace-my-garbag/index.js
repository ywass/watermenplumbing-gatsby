import React from 'react'
import Layout from '../../../../../components/layout'
import May18FirstBlog from '../../../../../components/BlogPages/2018Pages/May2018Pages/May18FirstBlog/May18FirstBlog'
function index() {
  return (
    <Layout>
        <May18FirstBlog/>
    </Layout>
  )
}

export default index