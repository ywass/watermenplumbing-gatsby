import React from 'react'
import Layout from '../../../../components/layout'
import May2018Pages from '../../../../components/BlogPages/2018Pages/May2018Pages/May2018Pages'
function index() {
  return (
    <Layout>
        <May2018Pages/>
    </Layout>
  )
}

export default index