import React from 'react'
import Layout from '../../../../../components/layout'
import Dec18FirstBlog from '../../../../../components/BlogPages/2018Pages/December2018Pages/Dec18FirstBlog/Dec18FirstBlog'
function index() {
  return (
    <Layout>
        <Dec18FirstBlog/>
    </Layout>
  )
}

export default index