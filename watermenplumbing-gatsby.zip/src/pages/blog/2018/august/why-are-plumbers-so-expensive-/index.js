import React from 'react'
import Layout from '../../../../../components/layout'
import Aug18FirstBlog from '../../../../../components/BlogPages/2018Pages/August2018Pages/Aug18FirstBlog/Aug18FirstBlog'
function index() {
  return (
    <Layout>
        <Aug18FirstBlog/>
    </Layout>
  )
}

export default index