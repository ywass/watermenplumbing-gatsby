import React from 'react'
import SpecticTanksPage from '../../../../components/BlogPages/CategoriesPages/SpecticTanksPage/SpecticTanksPage'
import Layout from '../../../../components/layout'
function index() {
  return (
    <Layout>
     <SpecticTanksPage/>
    </Layout>
  )
}

export default index