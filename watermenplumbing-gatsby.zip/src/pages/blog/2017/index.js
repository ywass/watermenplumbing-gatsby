import React from 'react'
import Layout from '../../../components/layout'
import TwentySeventeenPages from '../../../components/BlogPages/2017Pages/2017Pages'
function index() {
  return (
    <Layout>
        <TwentySeventeenPages/>
    </Layout>
  )
}

export default index