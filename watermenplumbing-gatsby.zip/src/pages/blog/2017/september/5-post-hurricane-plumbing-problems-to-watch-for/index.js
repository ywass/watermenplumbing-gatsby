import React from 'react'
import Layout from '../../../../../components/layout'
import Sep17FirstBlog from '../../../../../components/BlogPages/2017Pages/Sep17Pages/Sep17FirstBlog/Sep17FirstBlog'
function index() {
  return (
    <Layout>
        <Sep17FirstBlog/>
    </Layout>
  )
}

export default index