import React from 'react'
import Layout from '../../../../components/layout'
import April2017Pages from '../../../../components/BlogPages/2017Pages/April17Pages/April17Pages'
function index() {
  return (
    <Layout>
        <April2017Pages/>
    </Layout>
  )
}

export default index