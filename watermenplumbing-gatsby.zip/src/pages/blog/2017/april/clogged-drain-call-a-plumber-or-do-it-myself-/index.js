import React from 'react'
import Layout from '../../../../../components/layout'
import Apr17FirstBlog from '../../../../../components/BlogPages/2017Pages/April17Pages/April17FirstBlog/April17FirstBlog'
function index() {
  return (
    <Layout>
        <Apr17FirstBlog/>
    </Layout>
  )
}

export default index