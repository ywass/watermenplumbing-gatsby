import React from 'react'
import Layout from '../../../../../components/layout'
import Jun19FirstBlog from '../../../../../components/BlogPages/2019Pages/June2019Pages/Jun19FirstBlog/Jun19FirstBlog'
function index() {
  return (
    <Layout>
        <Jun19FirstBlog/>
    </Layout>
  )
}

export default index