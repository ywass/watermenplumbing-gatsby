import React from 'react'
import Layout from '../../../../../components/layout'
import May2019FirstBlog from '../../../../../components/BlogPages/2019Pages/May2019Pages/May19FirstBlog/May19FirstBlog'
function index() {
  return (
    <Layout>
        <May2019FirstBlog/>
    </Layout>
  )
}

export default index