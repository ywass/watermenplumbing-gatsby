import React from 'react'
import Layout from '../../../components/layout'
import TwentyNineteenPages from '../../../components/BlogPages/2019Pages/2019Pages'
function index() {
  return (
    <Layout>
        <TwentyNineteenPages/>
    </Layout>
  )
}

export default index