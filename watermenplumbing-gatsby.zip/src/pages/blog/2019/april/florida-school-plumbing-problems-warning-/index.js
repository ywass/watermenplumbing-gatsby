import React from 'react'
import Layout from '../../../../../components/layout'
import Apr19FirstBlog from '../../../../../components/BlogPages/2019Pages/April2019Pages/Apr19FirstBlog/Apr19FirstBlog'
function index() {
  return (
    <Layout>
        <Apr19FirstBlog/>
    </Layout>
  )
}

export default index