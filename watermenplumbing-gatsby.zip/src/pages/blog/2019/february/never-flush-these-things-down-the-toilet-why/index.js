import React from 'react'
import Layout from '../../../../../components/layout'
import Feb19FirstBlog from '../../../../../components/BlogPages/2019Pages/February2019Pages/Feb19FirstBlog/Feb19FirstBlog'
function index() {
  return (
    <Layout>
        <Feb19FirstBlog/>
    </Layout>
  )
}

export default index