import React from 'react'
import January2022Pages from '../../../../components/BlogPages/2022Pages/January2022Pages/January2022Pages'
import Layout from '../../../../components/layout'
function index() {
  return (
    <Layout>
     <January2022Pages/>
    </Layout>
  )
}

export default index