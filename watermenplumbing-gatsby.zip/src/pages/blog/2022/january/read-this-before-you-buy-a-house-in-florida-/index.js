import React from 'react'
import Layout from '../../../../../components/layout'
import Jan22FirstBlog from '../../../../../components/BlogPages/2022Pages/January2022Pages/Jan22FirstBlog/Jan22FirstBlog'
function index() {
  return (
    <Layout>
      <Jan22FirstBlog/>
    </Layout>
  )
}

export default index