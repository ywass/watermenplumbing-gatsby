import React from 'react'
import TwentyTwoPages from '../../../components/BlogPages/2022Pages/2022Pages'
import Layout from '../../../components/layout'
function index() {
  return (
    <Layout>
     <TwentyTwoPages/>
    </Layout>
  )
}

export default index