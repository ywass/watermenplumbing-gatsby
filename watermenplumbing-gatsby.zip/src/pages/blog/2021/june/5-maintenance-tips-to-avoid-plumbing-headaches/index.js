import React from 'react'
import Jun21FirstBlog from '../../../../../components/BlogPages/2021Pages/June2021Pages/Jun21FirstBlog/Jun21FirstBlog'
import Layout from '../../../../../components/layout'
function index() {
  return (
    <Layout>
        <Jun21FirstBlog/>
    </Layout>
  )
}

export default index