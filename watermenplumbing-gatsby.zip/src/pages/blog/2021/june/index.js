import React from 'react'
import Layout from '../../../../components/layout'
import June2021Pages from '../../../../components/BlogPages/2021Pages/June2021Pages/June2021Pages'
function index() {
  return (
    <Layout>
        <June2021Pages/>
    </Layout>
  )
}

export default index