import React from 'react'
import Jul21FirstBlog from '../../../../../components/BlogPages/2021Pages/July2021Pages/Jul21FirstBlog/Jul21FirstBlog'
import Layout from '../../../../../components/layout'
function index() {
  return (
    <Layout>
        <Jul21FirstBlog/>
    </Layout>
  )
}

export default index