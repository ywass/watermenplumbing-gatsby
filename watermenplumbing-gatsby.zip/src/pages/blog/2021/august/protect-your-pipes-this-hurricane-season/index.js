import React from 'react'
import Aug21FirstBlog from '../../../../../components/BlogPages/2021Pages/August2021Pages/Aug21FirstBlog/Aug21FirstBlog'
import Layout from '../../../../../components/layout'
function index() {
  return (
    <Layout>
        <Aug21FirstBlog/>
    </Layout>
  )
}

export default index