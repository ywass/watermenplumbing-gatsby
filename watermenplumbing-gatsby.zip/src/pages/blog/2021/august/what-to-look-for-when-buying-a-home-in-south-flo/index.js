import React from 'react'
import Layout from '../../../../../components/layout'
import Aug21SecondBlog from '../../../../../components/BlogPages/2021Pages/August2021Pages/Aug21SecondBlog/Aug21SecondBlog'
function index() {
  return (
    <Layout>
        <Aug21SecondBlog/>
    </Layout>
  )
}

export default index