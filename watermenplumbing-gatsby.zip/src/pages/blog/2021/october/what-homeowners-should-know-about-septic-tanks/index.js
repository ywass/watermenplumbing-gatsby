import React from 'react'
import Oct21FirstBlog from '../../../../../components/BlogPages/2021Pages/October2021Pages/Oct21FirstBlog/Oct21FirstBlog'
import Layout from '../../../../../components/layout'
function index() {
  return (
    <Layout>
        <Oct21FirstBlog/>
    </Layout>
  )
}

export default index