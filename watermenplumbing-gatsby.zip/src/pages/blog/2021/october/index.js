import React from 'react'
import October2021Pages from '../../../../components/BlogPages/2021Pages/October2021Pages/October2021Pages'
import Layout from '../../../../components/layout'
function index() {
  return (
    <Layout>
     <October2021Pages/>
    </Layout>
  )
}

export default index