import React from 'react'
import Jan21FirstBlog from '../../../../../components/BlogPages/2021Pages/January2021Pages/Jan21FirstBlog/Jan21FirstBlog'
import Layout from '../../../../../components/layout'
function index() {
  return (
    <Layout>
        <Jan21FirstBlog/>
    </Layout>
  )
}

export default index