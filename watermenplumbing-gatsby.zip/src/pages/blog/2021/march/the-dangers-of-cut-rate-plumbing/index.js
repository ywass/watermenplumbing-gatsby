import React from 'react'
import Mar21SecondBlog from '../../../../../components/BlogPages/2021Pages/March2021Pages/Mar21SecondBlog/Mar21SecondBlog'
import Layout from '../../../../../components/layout'
function index() {
  return (
    <Layout>
        <Mar21SecondBlog/>
    </Layout>
  )
}

export default index