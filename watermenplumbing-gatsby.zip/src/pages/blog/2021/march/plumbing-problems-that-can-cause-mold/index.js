import React from 'react'
import Mar21FirstBlog from '../../../../../components/BlogPages/2021Pages/March2021Pages/Mar21FirstBlog/Mar21FirstBlog'
import Layout from '../../../../../components/layout'
function index() {
  return (
    <Layout>
        <Mar21FirstBlog/>
    </Layout>
  )
}

export default index