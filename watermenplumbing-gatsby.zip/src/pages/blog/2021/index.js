import React from 'react'
import TwentyOnePages from '../../../components/BlogPages/2021Pages/2021Pages'
import Layout from '../../../components/layout'
function index() {
  return (
    <Layout>
     <TwentyOnePages/>
    </Layout>
  )
}

export default index