import React from 'react'
import Layout from '../../components/layout'
import SiteSearchPage from '../../components/SiteSearchPage/SiteSearchPage'
function index() {
  return (
    <Layout>
     <SiteSearchPage/>
    </Layout>
  )
}

export default index