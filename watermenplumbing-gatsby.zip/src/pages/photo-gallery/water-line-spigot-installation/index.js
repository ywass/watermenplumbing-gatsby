import React from 'react'
import Layout from '../../../components/layout'
import WaterLineSpiInstallPhoto from '../../../components/WaterLineSpiInstallPhoto/WaterLineSpiInstallPhoto'
function index() {
  return (
    <Layout>
     <WaterLineSpiInstallPhoto/>
    </Layout>
  )
}

export default index