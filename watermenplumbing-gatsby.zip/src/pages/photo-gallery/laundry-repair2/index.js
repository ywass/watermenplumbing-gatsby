import React from 'react'
import LaundaryTwoRepairPhoto from '../../../components/LaundaryTwoRepairPhoto/LaundaryTwoRepairPhoto'
import Layout from '../../../components/layout'
function index() {
  return (
    <Layout>
     <LaundaryTwoRepairPhoto/>
    </Layout>
  )
}

export default index