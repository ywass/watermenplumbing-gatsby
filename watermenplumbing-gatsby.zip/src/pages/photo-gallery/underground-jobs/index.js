import React from 'react'
import Layout from '../../../components/layout'
import UndergroundJobsPhoto from '../../../components/UndergroundJobsPhoto/UndergroundJobsPhoto'
function index() {
  return (
    <Layout>
       <UndergroundJobsPhoto/>
    </Layout>
  )
}

export default index