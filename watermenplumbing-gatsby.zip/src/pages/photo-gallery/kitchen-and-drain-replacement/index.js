import React from 'react'
import KitchenDrainPhoto from '../../../components/KitchenDrainPhoto/KitchenDrainPhoto'
import Layout from '../../../components/layout'
function index() {
  return (
    <Layout>
      <KitchenDrainPhoto/>
    </Layout>
  )
}

export default index