import React from 'react'
import Layout from '../../../components/layout'
import WholeHouseWaterRepipePhoto from '../../../components/WholeHouseWaterRepipePhoto/WholeHouseWaterRepipePhoto'
function index() {
  return (
    <Layout>
     <WholeHouseWaterRepipePhoto/>
    </Layout>
  )
}

export default index