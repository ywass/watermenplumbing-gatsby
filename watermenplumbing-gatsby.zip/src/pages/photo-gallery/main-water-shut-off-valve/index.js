import React from 'react'
import Layout from '../../../components/layout'
import MainWaterShutOffPhoto from '../../../components/MainWaterShutOffPhoto/MainWaterShutOffPhoto'
function index() {
  return (
    <Layout>
     <MainWaterShutOffPhoto/>
    </Layout>
  )
}

export default index