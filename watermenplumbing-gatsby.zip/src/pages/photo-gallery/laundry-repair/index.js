import React from 'react'
import LaundaryRepairPhoto from '../../../components/LaundaryRepairPhoto/LaundaryRepairPhoto'
import Layout from '../../../components/layout'
function index() {
  return (
    <Layout>
      <LaundaryRepairPhoto/>
    </Layout>
  )
}

export default index