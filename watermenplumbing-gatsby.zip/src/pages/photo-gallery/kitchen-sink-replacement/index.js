import React from 'react'
import KitchenSinkReplacePhoto from '../../../components/KitchenSinkReplacePhoto/KitchenSinkReplacePhoto'
import Layout from '../../../components/layout'
function index() {
  return (
    <Layout>
     <KitchenSinkReplacePhoto/>
    </Layout>
  )
}

export default index