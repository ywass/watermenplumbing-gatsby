import React from 'react'
import Layout from '../../../components/layout'
import MainValveRepPhoto from '../../../components/MainValveRepPhoto/MainValveRepPhoto'
function index() {
  return (
    <Layout>
      <MainValveRepPhoto/>
    </Layout>
  )
}

export default index