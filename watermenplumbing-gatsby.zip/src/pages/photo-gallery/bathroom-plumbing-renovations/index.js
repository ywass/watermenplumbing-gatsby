import React from 'react'
import BathPlumbingRenoPhoto from '../../../components/BathPlumbingRenoPhoto/BathPlumbingRenoPhoto'
import Layout from '../../../components/layout'
function index() {
  return (
    <Layout>
     <BathPlumbingRenoPhoto/>
    </Layout>
  )
}

export default index