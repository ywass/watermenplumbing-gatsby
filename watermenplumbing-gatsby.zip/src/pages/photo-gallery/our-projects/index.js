import React from 'react'
import Layout from '../../../components/layout'
import OurProjectsPhoto from '../../../components/OurProjectsPhoto/OurProjectsPhoto'
function index() {
  return (
    <Layout>
     <OurProjectsPhoto/>
    </Layout>
  )
}

export default index