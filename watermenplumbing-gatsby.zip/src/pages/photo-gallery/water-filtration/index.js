import React from 'react'
import Layout from '../../../components/layout'
import WaterFilterationPhoto from '../../../components/WaterFilterationPhoto/WaterFilterationPhoto'
function index() {
  return (
    <Layout>
     <WaterFilterationPhoto/>
    </Layout>
  )
}

export default index