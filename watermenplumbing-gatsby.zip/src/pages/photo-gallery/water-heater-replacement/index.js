import React from 'react'
import Layout from '../../../components/layout'
import WaterHeaterReplacePhoto from '../../../components/WaterHeaterReplacePhoto/WaterHeaterReplacePhoto'
function index() {
  return (
    <Layout>
     <WaterHeaterReplacePhoto/>
    </Layout>
  )
}

export default index