import React from 'react'
import Layout from '../../../components/layout'
import SiliconeCaulkingBandAPhoto from '../../../components/SiliconeCaulkingBandAPhoto/SiliconeCaulkingBandAPhoto'
function index() {
  return (
    <Layout>
     <SiliconeCaulkingBandAPhoto/>
    </Layout>
  )
}

export default index