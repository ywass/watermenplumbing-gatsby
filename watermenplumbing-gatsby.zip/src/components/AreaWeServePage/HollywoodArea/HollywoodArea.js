import React from 'react'
import '../../../style/areaWeServe.css'
import subBannerBgImg from '../../../images/sub-banner-v1-bg.jpg'
import senoirImg from '../../../images/Senoir[9].jpg'
import letUsImg from '../../../images/Let-us.jpg'
import stayLoopImg from '../../../images/Stay-in-loop.jpg'
import saveServiceImg from '../../../images/Save-on-service.jpg'

import ctaV13Bg from '../../../images/cta-v13-bg.jpeg'
import tltBdrImg from '../../../images/tlt-bdr.png'
import tltBdr2Img from '../../../images/tlt-bdr2.png'
import PanelGroupImg from "../../../images/values-v9-bg.jpg"

import valuesV9Img from '../../../images/values-v9-img.png'
import { Link } from 'gatsby'
import AsideForm from '../../../ReuseComponents/AsideForm/AsideForm'
function HollywoodArea() {
  return (
    <main id="MainZone">
  <section
    className="sub-banner v1 bg-image dark-bg bg-box-none text-left"
    id="SubBannerV1"
    data-onvisible="show"
  >
    <picture className="img-bg bg-position" role="presentation">
      <source
        media="(max-width: 500px)"
        srcSet="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="
        data-src="/assets/sub-banners/sub-banner-v1-bg-mobile.jpg"
      />
      <img
        alt=""
        src={subBannerBgImg}
      />
    </picture>
    <div className="main">
      <div
        className="bg-box side-padding-medium vertical-padding info text-align center-500 box-flair"
        id="SubBannerV1Info"
      >
        <div className="flair-border">
          <span className="flair-1" />
          <span className="flair-2" />
          <span className="title-font title-color-1">
            <strong>Hollywood</strong>
          </span>
          <em className="title-color-2 subtitle">
            We’ll Treat Your Home as if It Were Our Own
          </em>
          <img src={tltBdrImg} className="header-flair"/>
        </div>
      </div>
    </div>
  </section>
  <section
    className="two-column-layout light-bg col-66-33 vertical-padding items-spaced flow-reverse transparent-bg large-padding"
    id="TwoColumnLayout"
  >
    <div className="main flex-spaced-between-block-1024-margined item-spacing item-widths flex-direction">
      <div className="content-zone" id="ContentZone">
        <div
          className="column-layout-content transparent-bg bg-box-none light-bg"
          id="ColumnLayoutContent"
          data-onvisible="show"
        >
          <div className="bg-box side-padding-medium vertical-padding-small box-flair border-radius">
            <div className="flair-border" data-content="true">
              <span className="flair-1" />
              <span className="flair-2" />
              <div
                className="content-style"
                id="MainContent"
                data-content="true"
              >
                <h1>Plumbing Services in Hollywood</h1>
                <h2>
                  Get the General Plumbing Services You Need for Simple
                  Maintenance and Emergency Repairs
                </h2>
                <p>
                  At Watermen Plumbing, we offer a wide range of plumbing
                  services to the community of Hollywood, Florida. Floridians in
                  the area have come to know and trust our team for the ability
                  to provide reliable plumbing solutions. We know that your home
                  is an important investment, and we think of your plumbing
                  systems as the backbone that holds it all together. However,
                  such an important system cannot be left up to its own devices.
                  There are regular maintenance calls, repair services, and
                  various installation processes that go into maintaining a
                  functioning plumbing system, and our team can do it all.
                  <b>
                    Some of the most common requests we get for
                    <Link to="/plumbing-services"> plumbing services
                    </Link>{" "}
                    in Hollywood include:
                  </b>
                </p>
                <ul>
                  <li>
                    <Link to="/plumbing-services/drain-issues/drain-cleaning-snaking">
                      <b>Snaking and fixing clogged drains </b>
                    </Link>
                  </li>
                </ul>
                <p>
                  When it comes to cleaning your sewer lines, a good rule of
                  thumb is to have them cleaned out every 18 to 22 months.
                  Otherwise, you might find that your drain gets clogged more
                  often and that it needs to undergo this repair more
                  frequently. You might have heard horror stories about snakes
                  coming out of pipes, but a plumber’s snakes are a bit
                  different than the reptiles you might be imagining. A
                  plumber’s snake works by entering the drain directly to make
                  contact with and clear away the obstruction that causes the
                  clog. This popular and simple service will have your toilets
                  flushing with ease as soon as possible.
                </p>
                <ul>
                  <li>
                    <Link to="/plumbing-services/whole-home-repiping">
                      <b>Re-piping </b>
                    </Link>
                  </li>
                </ul>
                <p>
                  Florida presents some unique issues when it comes to sewage
                  pipes, and the community of Hollywood is no exception. It
                  could be due to the high levels of chlorine in the water
                  supply, microbial activity, or high pH levels. The most likely
                  explanation for most systems is that a combination of these
                  factors lead to damaged pipes and leaks. If you think you have
                  a water leak, it is important to detect it early. Otherwise,
                  your system might have to undergo more extensive repairs
                  later. If you notice increasing water bills, visible mold and
                  mildew, musty smelling rooms, stained and damaged ceilings,
                  walls, and floors, wet spots, or foundation cracks, you might
                  have a leak. Our team has the skills and knowledge necessary
                  to determine the severity of these spots and determine whether
                  you need a re-piping or if there is another solution. We will
                  always be honest when we provide these recommendations and
                  will only recommend services you truly need.
                </p>
                <ul>
                  <li>
                    <Link to="/plumbing-services/sewer-services">
                      <b>Sewer repairs</b>
                    </Link>
                  </li>
                </ul>
                <p>
                  Nowadays, there are plenty of approaches we can take to repair
                  your sewer line if you come across an issue. Some of the ways
                  you can tell that your sewer line needs to be repaired include
                  an odor of sewer gas, slow drains, and clogs and backups. The
                  best way to prevent this issue is to undergo regular
                  maintenance, and the best way to detect the issue and stop it
                  in its tracks is to consult with an expert. One of our
                  plumbing professionals will be able to thoroughly inspect your
                  sewer to uncover the true cause of the issue and recommend the
                  best repair possible. Some of the most popular sewer repairs
                  methods include trenchless sewer methods, pipe bursting,
                  cured-in place pipelining (CIPP), and slip lining.
                </p>
                <h3>
                  Top Qualities to Look for When Finding a Good Plumber in
                  Hollywood
                </h3>
                <p>
                  When you pick a plumber, you are placing a great deal of trust
                  in that individual to handle the intricate systems that keep
                  your home functioning and maintain its value. That is why
                  picking a plumber goes beyond choosing someone who is familiar
                  with the systems necessary to maintain your home. This is
                  certainly important, but you also want a plumber who will turn
                  what can be a stressful process into a smooth and enjoyable
                  one. That level of commitment to your positive experience is
                  what you will find in Hollywood at Watermen Plumbing.
                  <b>
                    Some of the qualities we embody that we believe are
                    important for every plumber to have include:
                  </b>
                </p>
                <ul>
                  <li>Proper certification</li>
                  <li>Years of experience</li>
                  <li>Familiar with mechanical components of a home</li>
                  <li>Adherence to safety</li>
                  <li>Capable of maneuvering heavy objects</li>
                  <li>Punctuality</li>
                  <li>Highly coordinated</li>
                  <li>Ability to solve problems</li>
                  <li>Ability to communicate</li>
                  <li>Dedication to the craft</li>
                </ul>
                <p
                  align="center"
                  className="text-highlight v1 bg-box unlike-bg side-padding-medium vertical-padding-tiny"
                >
                  <b>
                    To get access to the quality plumbing services you need in
                    Hollywood, call Watermen Plumbing at{" "}
                    <span
                      id="ColumnLayoutContent_1"
                      data-process="replace"
                      data-replace="{F:P:Cookie:PPCP1/(954)%20997-5797}"
                    > (954) 997-5797
                    </span>{" "}
                    or
                    <Link to="/contact-us"> contact us online
                    </Link>
                    .
                  </b>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="side-zone" id="SideZone">
        <aside
          className="side-nav v2 border-radius-item box-shadow dark-bg"
          id="SideNavV2"
          data-onvisible="show"
        >
          <nav>
            <header className="text-left">
              <Link to="/about-us/areas-we-serve">
                <h5>Areas We Serve</h5>
              </Link>
            </header>
            <ul className="el-tab-box" role="menu">
              <li className="level-1  ">
                <Link
                  className="pseudo-before relative auto"
                  to="/about-us/areas-we-serve/broward-county"
                  target=""
                  role="menuitem"
                >
                  Broward County
                </Link>
              </li>
              <li className="level-1  ">
                <Link
                  className="pseudo-before relative auto"
                  to="/about-us/areas-we-serve/coral-springs"
                  target=""
                  role="menuitem"
                >
                  Coral Springs
                </Link>
              </li>
              <li className="level-1  ">
                <Link
                  className="pseudo-before relative auto"
                  to="/about-us/areas-we-serve/davie"
                  target=""
                  role="menuitem"
                >
                  Davie
                </Link>
              </li>
              <li className="level-1  ">
                <Link
                  className="pseudo-before relative auto"
                  to="/about-us/areas-we-serve/fort-lauderdale"
                  target=""
                  role="menuitem"
                >
                  Fort Lauderdale
                </Link>
              </li>
              <li className="level-1 selected ">
                <Link
                  className="pseudo-before relative auto"
                  to="/about-us/areas-we-serve/hollywood"
                  target=""
                  role="menuitem"
                >
                  Hollywood
                </Link>
              </li>
              <li className="level-1  ">
                <Link
                  className="pseudo-before relative auto"
                  to="/about-us/areas-we-serve/miramar"
                  target=""
                  role="menuitem"
                >
                  Miramar
                </Link>
              </li>
              <li className="level-1  ">
                <Link
                  className="pseudo-before relative auto"
                  to="/about-us/areas-we-serve/plantation"
                  target=""
                  role="menuitem"
                >
                  Plantation
                </Link>
              </li>
              <li className="level-1  ">
                <Link
                  className="pseudo-before relative auto"
                  to="/about-us/areas-we-serve/hallandale-beach"
                  target=""
                  role="menuitem"
                >
                  Hallandale Beach
                </Link>
              </li>
            </ul>
          </nav>
        </aside>
        <AsideForm/>
        <aside
          className="side-coupon v1 light-bg transparent-bg no-shadow bg-box-unlike"
          id="SideCouponV1"
          data-onvisible="show"
          data-role="scroller"
        >
          <div
            id="SideCouponV1List"
            className="ui-repeater"
            data-role="container"
          >
            <ul className="flex-" data-role="list">
              <li
                className="flex- coupon-style full border-radius"
                data-role="item"
                data-item="i"
                data-key={7622}
              >
                <div className="bg-box info flex-column-middle-center side-padding-large vertical-padding relative coupon-border pseudo-after text-center full">
                  <picture className="img-bg" role="presentation">
                    <source
                      media="(max-width: 500px)"
                      srcSet="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="
                      data-src="/images/coupons/Senoir[9].jpg"
                    />
                    <img
                      alt=""
                      src={senoirImg}
                    />
                  </picture>
                  <div className="full side-padding-small">
                    <strong className="title">
                      <strong className="title-font">
                        10<small>%</small> Off
                      </strong>
                      <span className="title-style-2 title-color-2">
                        Veteran Discount
                      </span>
                    </strong>
                    <div className="top-margin-tiny valid note-style">
                      <small>Valid from Jan 1, 2021</small>
                      <small>- Dec 31, 2022</small>
                    </div>
                    <div className="top-margin-small auto full">
                      <Link
                        className="btn v1"
                        to="/coupons"
                        target="_blank"
                      >
                        Print
                      </Link>
                    </div>
                  </div>
                </div>
              </li>
              <li
                className="flex- coupon-style full border-radius"
                data-role="item"
                data-item="i"
                data-key={7223}
              >
                <div className="bg-box info flex-column-middle-center side-padding-large vertical-padding relative coupon-border pseudo-after text-center full">
                  <picture className="img-bg" role="presentation">
                    <source
                      media="(max-width: 500px)"
                      srcSet="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="
                      data-src="/images/coupons/Senoir[9].jpg"
                    />
                    <img
                      alt=""
                      src={senoirImg}
                    />
                  </picture>
                  <div className="full side-padding-small">
                    <strong className="title">
                      <strong className="title-font">
                        10<small>%</small> Off
                      </strong>
                      <span className="title-style-2 title-color-2">
                        Senior Discount
                      </span>
                    </strong>
                    <p className="title-style-5 title-color-5 top-margin-tiny no-bottom-margin description">
                      Call for more details!
                    </p>
                    <div className="top-margin-tiny valid note-style">
                      <small>Valid from Nov 1, 2020</small>
                      <small>- Dec 31, 2022</small>
                    </div>
                    <div className="top-margin-small auto full">
                      <Link
                        className="btn v1"
                        to="/about-us/areas-we-serve/coupons"
                        target="_blank"
                      >
                        Print
                      </Link>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
            <div
              className="scrolling-list-nav top-margin horizontal flex-middle-center relative text-center"
              data-role="arrows"
            >
              <button
                title="View previous item"
                aria-label="View previous item"
                data-action="Prev"
              >
                <svg className="site-arrow">
                  <use href="../../../includes/flair.svg#arrow-left" />
                </svg>
              </button>
              <span className="paging" data-role="paging">
                <span data-role="page-active" /> /{" "}
                <span data-role="page-total" />
              </span>
              <button
                title="View next item"
                aria-label="View next item"
                data-action="Next"
              >
                <svg className="site-arrow">
                  <use href="../../../includes/flair.svg#arrow-right" />
                </svg>
              </button>
            </div>
            <div id="SideCouponV1BtnCon"></div>
          </div>
        </aside>
      </div>
    </div>
  </section>
  <section
    className="cta v13 light-bg text-left bg-image bg-box-unlike"
    id="CtaV13"
    data-onvisible="show"
  >
    <picture
      className="img-bg bg-position"
      role="presentation"
      data-role="picture"
    >
      <source
        media="(max-width: 500px)"
        srcSet="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="
        data-src="/assets/ctas/cta-v13-bg-mobile.jpg"
      />
      <source
        media="(max-width: 800px)"
        srcSet="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="
        data-src="/assets/ctas/cta-v13-bg-tablet.jpg"
      />
      <img
        alt=""
        src={ctaV13Bg}
      />
    </picture>
    <div className="main">
      <header className="text-align center-800" id="CtaV13Header" />
      <ul
        className="cta-list flex-grid-center-block-800-auto-size-wrap-max-3-break-1024 close-gap-800 text-align"
        id="CtaV13List"
      >
        <li className="flex- fit" data-item="i">
          <Link
            className="bg-box scaling-img-item border-radius-item side-padding-medium vertical-padding-small text-center full"
            to="/photo-gallery"
          >
            <div className="img pad-height- bottom-margin">
              <img
                style={{
                  backgroundImage: `url(${letUsImg})`
                }}
                alt=""
                role="presentation"
              />
            </div>
            <div className="info">
              <strong className="title-style-2 title-color-2">
                See Us In Action
              </strong>
              <span className="btn v1 top-margin-small">View Our Gallery</span>
            </div>
          </Link>
        </li>
        <li className="flex- fit" data-item="i">
          <Link
            className="bg-box scaling-img-item border-radius-item side-padding-medium vertical-padding-small text-center full"
            to="/blog"
          >
            <div className="img pad-height- bottom-margin">
              <img
                style={{
                  backgroundImage: `url(${stayLoopImg})`
                }}
                alt=""
                role="presentation"
              />
            </div>
            <div className="info">
              <strong className="title-style-2 title-color-2">
                Stay In The Loop
              </strong>
              <span className="btn v1 top-margin-small">Read Our bLogs</span>
            </div>
          </Link>
        </li>
        <li className="flex- fit" data-item="i">
          <Link
            className="bg-box scaling-img-item border-radius-item side-padding-medium vertical-padding-small text-center full"
            to="/coupons"
          >
            <div className="img pad-height- bottom-margin">
              <img
                style={{
                  backgroundImage:`url(${saveServiceImg})`
                }}
                alt=""
                role="presentation"
              />
            </div>
            <div className="info">
              <strong className="title-style-2 title-color-2">
                Save On Services
              </strong>
              <span className="btn v1 top-margin-small">View our Offers</span>
            </div>
          </Link>
        </li>
      </ul>
    </div>
  </section>
  <section
    className="values v9 light-bg text-center bg-box-none vertical-top bg-image"
    id="ValuesV9"
    data-onvisible="show"
  >
    <Link name="valuesAnchor" />
    <picture className="img-bg" role="presentation" data-role="picture">
      <source
        media="(max-width: 500px)"
        srcSet="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="
        data-src="../../../assets/values/values-v9-bg-mobile.jpg"
      />
      <img
        alt=""
        title=""
        src={PanelGroupImg}
      />
    </picture>
    <div className="main relative">
      <header className="text-align center-500" id="ValuesV9Header">
        <h4>Why Customers Choose Us?</h4>
        <strong>We Believe That Only the Best Is Good Enough, For You!</strong>
        <img src={tltBdr2Img} className="header-flair"/>
      </header>
      <div className="relative vertical-padding">
        <ul
          className="values-list flex-wrap-block-1280-spaced-between ui-repeater"
          id="ValuesV9List"
        >
          <li
            className="flex-block-500 align-items center-500 top-margin-large "
            data-item="i"
            data-key={15797}
          >
            <span className="ico-con">
              <svg
                viewBox="0 0 24 24"
                className="values-icon"
                role="presentation"
              >
                <use data-href="../../../cms/svg/site/ykmkv4_n6ok.24.svg#saftey" />
              </svg>
            </span>
            <div className="info">
              <strong className="title-style-4 title-color-4">
                Customer &amp; Employee Safety First
              </strong>
              <p>
                We truly care about the health and safety of our staff and
                customers. We wear full PPE gear to ensure everyone is
                protected.
              </p>
            </div>
          </li>
          <li
            className="flex-block-500 align-items center-500 top-margin-large "
            data-item="i"
            data-key={15796}
          >
            <span className="ico-con">
              <svg
                viewBox="0 0 24 24"
                className="values-icon"
                role="presentation"
              >
                <use data-href="../../../cms/svg/site/ykmkv4_n6ok.24.svg#knowledge" />
              </svg>
            </span>
            <div className="info">
              <strong className="title-style-4 title-color-4">
                Knowledgeable &amp; Skilled Technicians
              </strong>
              <p />
              <p>
                Our technicians undergo weekly continuing education classes and
                are tested weekly to ensure quality control, and customer
                satisfaction.
              </p>
              <p />
            </div>
          </li>
          <li
            className="flex-block-500 align-items center-500 top-margin-large "
            data-item="i"
            data-key={15795}
          >
            <span className="ico-con">
              <svg
                viewBox="0 0 24 24"
                className="values-icon"
                role="presentation"
              >
                <use data-href="../../../cms/svg/site/ykmkv4_n6ok.24.svg#honest" />
              </svg>
            </span>
            <div className="info">
              <strong className="title-style-4 title-color-4">
                Reliable Honest Company
              </strong>
              <p>
                We provide peace of mind and stand behind our work with a 1-year
                warranty.
              </p>
            </div>
          </li>
          <li
            className="flex-block-500 align-items center-500 top-margin-large "
            data-item="i"
            data-key={15794}
          >
            <span className="ico-con">
              <svg
                viewBox="0 0 24 24"
                className="values-icon"
                role="presentation"
              >
                <use data-href="../../../cms/svg/site/ykmkv4_n6ok.24.svg#truck" />
              </svg>
            </span>
            <div className="info">
              <strong className="title-style-4 title-color-4">
                Fully Stocked Trucks
              </strong>
              <p>
                With the latest plumbing technology at our disposal, our team is
                prepared to handle your job in one trip.
              </p>
            </div>
          </li>
        </ul>
        <picture
          className="img bg-position"
          role="presentation"
          data-role="picture"
        >
          <source
            media="(max-width: 500px)"
            srcSet="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="
            data-src="../../../assets/values/values-v9-img-mobile.png"
          />
          <img
            alt=""
            src={valuesV9Img}
          />
        </picture>
      </div>
    </div>
  </section>
</main>

  )
}

export default HollywoodArea